// ============================================================
// data/portfolio.ts — All static portfolio content
// ============================================================
import { Project, Skill, TimelineItem, BlogPost } from '@/types';

export const PERSONAL_INFO = {
  name: 'Alex Rivera',
  title: 'Full-Stack Developer & Designer',
  tagline: 'Crafting digital experiences where code meets creativity.',
  bio: `I'm a passionate full-stack developer and UI/UX designer competing in SkillsUSA 2025. I love building elegant solutions to complex problems — from database architecture to pixel-perfect interfaces. Currently a senior at Valley Tech High School, I've shipped real products used by thousands of people and won regional coding competitions.`,
  bioExtended: `My journey started at 13 when I built my first website for my mom's bakery. Since then, I've fallen in love with the entire stack — React frontends, Node.js backends, cloud infrastructure, and everything in between. I believe great software isn't just functional — it's beautiful, accessible, and delightful to use.`,
  location: 'California, USA',
  email: 'alex.rivera@example.com',
  github: 'https://github.com/alexrivera',
  linkedin: 'https://linkedin.com/in/alexrivera',
  twitter: 'https://twitter.com/alexrivera',
  resumeUrl: '/resume.pdf',
  avatar: '/images/avatar.jpg',
  skillsusa: {
    chapter: 'Valley Tech SkillsUSA Chapter',
    competition: 'Web Design Technology',
    year: '2025',
    region: 'California State',
    achievements: [
      'Regional Gold Medalist 2024',
      'State Qualifier 2024',
      'National Competitor 2023',
    ],
  },
};

export const PROJECTS: Project[] = [
  {
    id: '1',
    title: 'EduConnect Platform',
    description: 'A full-stack learning management system connecting students and teachers with real-time collaboration, assignments, and progress tracking.',
    longDescription: 'EduConnect was built to solve the disconnect I noticed in online learning. Students and teachers needed a unified platform for assignments, video calls, chat, and progress analytics. Built with Next.js, WebSockets for real-time features, and PostgreSQL for robust data management.',
    techStack: ['Next.js', 'TypeScript', 'PostgreSQL', 'WebSockets', 'Tailwind CSS', 'Vercel'],
    imageUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&q=80',
    githubUrl: 'https://github.com/alexrivera/educonnect',
    liveUrl: 'https://educonnect.vercel.app',
    featured: true,
    category: 'web',
    year: 2024,
  },
  {
    id: '2',
    title: 'TaskFlow AI',
    description: 'An intelligent task management app that uses AI to prioritize your work, estimate completion times, and suggest optimal scheduling.',
    longDescription: 'TaskFlow AI combines traditional project management with GPT-4 intelligence. It learns your working patterns and automatically prioritizes tasks, warns you about scope creep, and generates progress reports. Used by 500+ beta users.',
    techStack: ['React', 'Node.js', 'MongoDB', 'OpenAI API', 'Express', 'Tailwind CSS'],
    imageUrl: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=800&q=80',
    githubUrl: 'https://github.com/alexrivera/taskflow-ai',
    liveUrl: 'https://taskflow-ai.vercel.app',
    featured: true,
    category: 'ai',
    year: 2024,
  },
  {
    id: '3',
    title: 'ShopLocal Marketplace',
    description: 'A hyperlocal e-commerce platform empowering small businesses to sell online with inventory management, payments, and analytics.',
    longDescription: 'ShopLocal was my response to seeing small businesses struggle during the pandemic. Built a complete marketplace with Stripe payments, inventory tracking, order management, and customer analytics. 12 local businesses onboarded in pilot.',
    techStack: ['React', 'Express', 'PostgreSQL', 'Stripe API', 'Redis', 'AWS S3'],
    imageUrl: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=800&q=80',
    githubUrl: 'https://github.com/alexrivera/shoplocal',
    liveUrl: 'https://shoplocal.app',
    featured: true,
    category: 'web',
    year: 2023,
  },
  {
    id: '4',
    title: 'Pulse Health Tracker',
    description: 'A React Native mobile app for tracking fitness goals, nutrition, and mental wellness with beautiful charts and personalized insights.',
    longDescription: 'Pulse was built for a school health initiative. The app tracks workouts, meals, sleep, and mental health scores. Features Apple HealthKit integration, a social challenge system, and AI-generated weekly wellness reports.',
    techStack: ['React Native', 'Expo', 'Firebase', 'TypeScript', 'Victory Charts'],
    imageUrl: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=800&q=80',
    githubUrl: 'https://github.com/alexrivera/pulse-health',
    liveUrl: 'https://expo.dev/@alexrivera/pulse',
    featured: false,
    category: 'mobile',
    year: 2023,
  },
  {
    id: '5',
    title: 'DataViz Dashboard',
    description: 'A customizable data visualization dashboard for business analytics with drag-and-drop widgets and real-time data streaming.',
    longDescription: 'Built for a local startup needing executive dashboards. Features D3.js charts, WebSocket streaming, custom widget builder, and PDF export. Handles 10k+ daily events with sub-100ms query times.',
    techStack: ['React', 'D3.js', 'Node.js', 'WebSockets', 'PostgreSQL', 'Docker'],
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
    githubUrl: 'https://github.com/alexrivera/dataviz-dashboard',
    featured: false,
    category: 'web',
    year: 2024,
  },
  {
    id: '6',
    title: 'CryptoBot API',
    description: 'A backend microservice architecture for cryptocurrency price tracking, alerts, and portfolio management with REST and GraphQL APIs.',
    longDescription: 'CryptoBot is a showcase of clean backend architecture — microservices with Docker, GraphQL for flexible querying, Redis caching for performance, and webhook-based price alerts. Handles 50k API calls/day.',
    techStack: ['Node.js', 'GraphQL', 'Redis', 'Docker', 'PostgreSQL', 'Kubernetes'],
    imageUrl: 'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=800&q=80',
    githubUrl: 'https://github.com/alexrivera/cryptobot-api',
    featured: false,
    category: 'backend',
    year: 2023,
  },
];

export const SKILLS: Skill[] = [
  // Frontend
  { name: 'React / Next.js', level: 95, category: 'frontend' },
  { name: 'TypeScript', level: 90, category: 'frontend' },
  { name: 'Tailwind CSS', level: 92, category: 'frontend' },
  { name: 'Framer Motion', level: 80, category: 'frontend' },
  { name: 'Vue.js', level: 72, category: 'frontend' },
  // Backend
  { name: 'Node.js / Express', level: 90, category: 'backend' },
  { name: 'PostgreSQL', level: 85, category: 'backend' },
  { name: 'MongoDB', level: 82, category: 'backend' },
  { name: 'GraphQL', level: 75, category: 'backend' },
  { name: 'Redis', level: 70, category: 'backend' },
  // Languages
  { name: 'JavaScript', level: 96, category: 'language' },
  { name: 'Python', level: 78, category: 'language' },
  { name: 'Java', level: 68, category: 'language' },
  { name: 'SQL', level: 85, category: 'language' },
  // DevOps
  { name: 'Docker', level: 76, category: 'devops' },
  { name: 'AWS', level: 68, category: 'devops' },
  { name: 'Vercel / Netlify', level: 90, category: 'devops' },
  { name: 'Git / GitHub', level: 92, category: 'devops' },
  // Design
  { name: 'Figma', level: 85, category: 'design' },
  { name: 'UI/UX Principles', level: 88, category: 'design' },
  { name: 'Adobe XD', level: 72, category: 'design' },
];

export const TIMELINE: TimelineItem[] = [
  {
    year: '2025',
    title: 'SkillsUSA State Competitor',
    subtitle: 'Web Design Technology',
    description: 'Competing at the California State SkillsUSA competition after earning a Gold Medal at Regionals. Building this portfolio as the competition deliverable.',
    type: 'achievement',
  },
  {
    year: '2024',
    title: 'Regional Gold Medalist',
    subtitle: 'SkillsUSA Web Design Technology',
    description: 'Won first place at the regional SkillsUSA competition, advancing to state. Judged on design excellence, technical implementation, and professional presentation.',
    type: 'achievement',
  },
  {
    year: '2024',
    title: 'Senior Developer Intern',
    subtitle: 'TechStart Inc. — Remote',
    description: 'Interned on the platform team, shipping features used by 50k+ users. Migrated legacy jQuery frontend to React, improving Lighthouse score from 42 to 96.',
    type: 'work',
  },
  {
    year: '2023',
    title: 'AP Computer Science A',
    subtitle: 'Valley Tech High School — Score: 5',
    description: 'Achieved a perfect score on the AP CS exam. Also completed online courses in Data Structures, Algorithms, and System Design.',
    type: 'education',
  },
  {
    year: '2023',
    title: 'National SkillsUSA Competitor',
    subtitle: 'Web Design Technology — Atlanta, GA',
    description: 'Competed nationally in Atlanta, representing California. Ranked in the top 10% nationally among over 300 competitors.',
    type: 'achievement',
  },
  {
    year: '2022',
    title: 'Founded School Coding Club',
    subtitle: 'Valley Tech High School',
    description: 'Founded and led the coding club from 0 to 45 members. Organized hackathons, workshops, and mentored younger students in web development basics.',
    type: 'work',
  },
  {
    year: '2021',
    title: 'First Website Launched',
    subtitle: 'Self-Taught Developer',
    description: 'Built my first real project — a bakery website for my mom. It got picked up by the local news and I was hooked. Learned HTML, CSS, and vanilla JS from scratch.',
    type: 'education',
  },
];

export const BLOG_POSTS: BlogPost[] = [
  {
    slug: 'building-accessible-react-apps',
    title: 'Building Truly Accessible React Applications',
    excerpt: 'Accessibility is not an afterthought — it\'s a fundamental design principle. Here\'s how I approach WCAG compliance in every project.',
    content: `# Building Truly Accessible React Applications\n\nAccessibility is one of those topics developers know they should care about but often push to "later." After judging our school's hackathon, I realized later never comes unless you build it in from day one.\n\n## The ARIA Trap\n\nMost developers think accessibility means adding \`aria-label\` to everything. That's not wrong, but it misses the bigger picture...`,
    date: '2024-03-15',
    readTime: '8 min read',
    tags: ['React', 'Accessibility', 'WCAG', 'TypeScript'],
    imageUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&q=80',
  },
  {
    slug: 'database-design-for-beginners',
    title: 'Database Design: What School Never Taught Me',
    excerpt: 'I learned more about databases from one production outage than from three textbooks. Here\'s the hard-won knowledge.',
    content: `# Database Design: What School Never Taught Me\n\nMy first real database design was a disaster. It worked fine locally, hit production with real users, and immediately fell apart...`,
    date: '2024-02-01',
    readTime: '12 min read',
    tags: ['Database', 'PostgreSQL', 'System Design', 'Backend'],
    imageUrl: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=800&q=80',
  },
  {
    slug: 'winning-skillsusa',
    title: 'How I Prepared for SkillsUSA Web Design Technology',
    excerpt: 'Behind the scenes of my competition prep: the tools, techniques, and mindset that helped me earn a Gold Medal at Regionals.',
    content: `# How I Prepared for SkillsUSA Web Design Technology\n\nWhen I first heard about SkillsUSA, I thought it was just a resume line. I was wrong. It's the most intense, rewarding technical challenge I've done...`,
    date: '2024-01-10',
    readTime: '6 min read',
    tags: ['SkillsUSA', 'Career', 'Web Design', 'Competition'],
    imageUrl: 'https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?w=800&q=80',
  },
];

export const TECH_STACK_LOGOS = [
  'React', 'Next.js', 'TypeScript', 'Node.js', 'PostgreSQL',
  'MongoDB', 'Tailwind CSS', 'Docker', 'AWS', 'Figma',
  'GraphQL', 'Redis', 'Vercel', 'Git', 'Python',
];

export const SKILLSUSA_VALUES = [
  {
    title: 'Technical Excellence',
    description: 'Mastery of full-stack development, modern frameworks, database design, and cloud deployment — demonstrating industry-level competency.',
    icon: 'Code2',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    title: 'Creative Problem Solving',
    description: 'Every project starts with a real problem. I research, prototype, iterate, and ship solutions that genuinely help people.',
    icon: 'Lightbulb',
    color: 'from-yellow-500 to-orange-500',
  },
  {
    title: 'Professionalism',
    description: 'Clean code, thorough documentation, accessibility compliance, and performance optimization — professional standards in every deliverable.',
    icon: 'Award',
    color: 'from-green-500 to-emerald-500',
  },
  {
    title: 'Community Leadership',
    description: 'Founded the school coding club, mentored peers, and contributed to open source — leadership extends beyond individual achievement.',
    icon: 'Users',
    color: 'from-purple-500 to-pink-500',
  },
];
