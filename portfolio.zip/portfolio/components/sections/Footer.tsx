// ============================================================
// components/sections/Footer.tsx
// ============================================================
'use client';

import React from 'react';
import { Github, Linkedin, Twitter, Code2, Heart } from 'lucide-react';
import { PERSONAL_INFO } from '@/data/portfolio';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border py-12">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gold/20 border border-gold/30 flex items-center justify-center">
              <Code2 size={16} className="text-gold" />
            </div>
            <span className="font-display text-lg font-medium" style={{ color: 'var(--gold)' }}>
              {PERSONAL_INFO.name}
            </span>
          </div>

          {/* Center */}
          <p className="text-sm text-muted-foreground flex items-center gap-1.5">
            Built with <Heart size={12} className="text-gold fill-gold" /> for SkillsUSA 2025
          </p>

          {/* Socials */}
          <div className="flex items-center gap-3">
            {[
              { href: PERSONAL_INFO.github, Icon: Github, label: 'GitHub' },
              { href: PERSONAL_INFO.linkedin, Icon: Linkedin, label: 'LinkedIn' },
              { href: PERSONAL_INFO.twitter, Icon: Twitter, label: 'Twitter' },
            ].map(({ href, Icon, label }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-gold hover:border-gold/40 transition-all duration-200"
              >
                <Icon size={15} />
              </a>
            ))}
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
          <p>© {year} {PERSONAL_INFO.name}. All rights reserved.</p>
          <p className="font-mono">
            Next.js · TypeScript · Tailwind CSS · Framer Motion
          </p>
        </div>
      </div>
    </footer>
  );
}
