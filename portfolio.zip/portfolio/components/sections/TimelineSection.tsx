// ============================================================
// components/sections/TimelineSection.tsx
// ============================================================
'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Trophy, Briefcase, GraduationCap } from 'lucide-react';
import { TIMELINE } from '@/data/portfolio';
import { cn } from '@/lib/utils';

const ICONS = {
  achievement: Trophy,
  work: Briefcase,
  education: GraduationCap,
};

const COLORS = {
  achievement: 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30',
  work: 'text-blue-400 bg-blue-400/10 border-blue-400/30',
  education: 'text-green-400 bg-green-400/10 border-green-400/30',
};

export default function TimelineSection() {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });

  return (
    <section id="timeline" className="py-32 relative" ref={ref}>
      <div className="max-w-4xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-3 mb-6"
        >
          <div className="w-8 h-px bg-gold" />
          <span className="text-gold text-sm font-mono tracking-widest uppercase">03 — Journey</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="section-heading text-foreground mb-16"
          style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}
        >
          My story so far
        </motion.h2>

        <div className="relative">
          {/* Vertical line */}
          <div className="timeline-line" />

          <div className="space-y-10 pl-20">
            {TIMELINE.map((item, i) => {
              const Icon = ICONS[item.type];
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.1 + i * 0.1 }}
                  className="relative group"
                >
                  {/* Icon bubble */}
                  <div className={cn(
                    'absolute -left-[3.25rem] top-0 w-10 h-10 rounded-xl border flex items-center justify-center transition-transform group-hover:scale-110',
                    COLORS[item.type]
                  )}>
                    <Icon size={16} />
                  </div>

                  {/* Content */}
                  <div className="p-6 rounded-2xl border border-border bg-card/30 hover:border-gold/20 hover:bg-card/50 transition-all duration-300">
                    <div className="flex items-start justify-between gap-4 mb-2 flex-wrap">
                      <div>
                        <h3 className="font-medium text-foreground text-base">{item.title}</h3>
                        <p className="text-sm text-gold/80">{item.subtitle}</p>
                      </div>
                      <span className="font-mono text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full flex-shrink-0">
                        {item.year}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
