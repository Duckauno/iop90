// ============================================================
// components/sections/SkillsUSASection.tsx
// ============================================================
'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Award, Code2, Lightbulb, Users, Trophy, ArrowRight } from 'lucide-react';
import { SKILLSUSA_VALUES, PERSONAL_INFO } from '@/data/portfolio';

const ICON_MAP: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  Code2,
  Lightbulb,
  Award,
  Users,
};

export default function SkillsUSASection() {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });

  return (
    <section id="skillsusa" className="py-32 relative overflow-hidden" ref={ref}>
      {/* Large BG text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
        <span
          className="text-[20rem] font-display font-bold text-foreground/[0.02] whitespace-nowrap"
          aria-hidden="true"
        >
          SKILLS
        </span>
      </div>

      <div className="max-w-6xl mx-auto px-6 relative z-10">
        {/* Label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-3 mb-6"
        >
          <div className="w-8 h-px bg-gold" />
          <span className="text-gold text-sm font-mono tracking-widest uppercase">05 — SkillsUSA</span>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-start mb-20">
          {/* Left */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
          >
            <h2
              className="section-heading text-foreground mb-6"
              style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}
            >
              Why SkillsUSA{' '}
              <em className="gradient-text not-italic">matters</em>
            </h2>

            <p className="text-muted-foreground leading-relaxed mb-6">
              SkillsUSA isn&apos;t just a competition — it&apos;s a proving ground for the next generation
              of technical professionals. The Web Design Technology category challenges competitors to
              demonstrate mastery across the full stack: design, development, accessibility, and performance.
            </p>

            <p className="text-muted-foreground leading-relaxed mb-8">
              This portfolio itself is my competition deliverable — every line of code, every design
              decision, every performance optimization reflects the standards I&apos;ve set for myself as
              a professional developer.
            </p>

            {/* Achievement badges */}
            <div className="space-y-3">
              {PERSONAL_INFO.skillsusa.achievements.map((achievement, i) => (
                <motion.div
                  key={achievement}
                  initial={{ opacity: 0, x: -15 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="flex items-center gap-3 p-4 rounded-xl border border-gold/20 bg-gold/5"
                >
                  <Trophy size={16} className="text-gold flex-shrink-0" />
                  <span className="text-sm font-medium text-foreground">{achievement}</span>
                  <ArrowRight size={14} className="ml-auto text-gold/50" />
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right: Competition details */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="p-8 rounded-3xl border border-gold/20 bg-card/50 gold-glow"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-gold/15 flex items-center justify-center">
                <Trophy size={22} className="text-gold" />
              </div>
              <div>
                <h3 className="font-medium text-foreground">Competition Details</h3>
                <p className="text-sm text-muted-foreground">SkillsUSA {PERSONAL_INFO.skillsusa.year}</p>
              </div>
            </div>

            <div className="space-y-4">
              {[
                { label: 'Event', value: PERSONAL_INFO.skillsusa.competition },
                { label: 'Chapter', value: PERSONAL_INFO.skillsusa.chapter },
                { label: 'Region', value: PERSONAL_INFO.skillsusa.region },
                { label: 'Year', value: PERSONAL_INFO.skillsusa.year },
                { label: 'Status', value: 'State Qualifier ✓' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-center py-3 border-b border-border/50 last:border-0">
                  <span className="text-sm text-muted-foreground">{label}</span>
                  <span className="text-sm font-medium text-foreground">{value}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 rounded-xl bg-gold/10 border border-gold/20">
              <p className="text-xs text-gold font-mono uppercase tracking-widest mb-1">Project Goal</p>
              <p className="text-sm text-foreground">
                Demonstrate professional-grade full-stack development, UI/UX design excellence, and
                technical problem-solving through a complete, production-ready portfolio website.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Core Values Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SKILLSUSA_VALUES.map((value, i) => {
            const Icon = ICON_MAP[value.icon] ?? Code2;
            return (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.3 + i * 0.1 }}
                className="p-6 rounded-2xl border border-border bg-card/40 hover:border-gold/30 hover:bg-card/70 transition-all duration-300 group"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${value.color} p-0.5 mb-4 group-hover:scale-110 transition-transform`}>
                  <div className="w-full h-full rounded-[10px] bg-background flex items-center justify-center">
                    <Icon size={20} className="text-foreground" />
                  </div>
                </div>
                <h3 className="font-medium text-foreground mb-2">{value.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{value.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
