// ============================================================
// components/sections/SkillsSection.tsx
// ============================================================
'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { SKILLS } from '@/data/portfolio';
import { cn } from '@/lib/utils';

const CATEGORIES = ['all', 'frontend', 'backend', 'language', 'devops', 'design'] as const;
type Category = (typeof CATEGORIES)[number];

const CATEGORY_LABELS: Record<Category, string> = {
  all: 'All Skills',
  frontend: 'Frontend',
  backend: 'Backend',
  language: 'Languages',
  devops: 'DevOps',
  design: 'Design',
};

export default function SkillsSection() {
  const [active, setActive] = useState<Category>('all');
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });

  const filtered = active === 'all' ? SKILLS : SKILLS.filter((s) => s.category === active);

  return (
    <section id="skills" className="py-32 relative" ref={ref}>
      {/* BG accent */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 rounded-full blur-3xl opacity-5"
        style={{ background: 'radial-gradient(circle, #C9A84C, transparent)' }} />

      <div className="max-w-6xl mx-auto px-6">
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-3 mb-6"
        >
          <div className="w-8 h-px bg-gold" />
          <span className="text-gold text-sm font-mono tracking-widest uppercase">02 — Skills</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="section-heading text-foreground mb-12"
          style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}
        >
          What I bring to the table
        </motion.h2>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-wrap gap-2 mb-12"
        >
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActive(cat)}
              className={cn(
                'px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200 border',
                active === cat
                  ? 'bg-gold text-navy border-gold shadow-lg shadow-gold/20'
                  : 'border-border text-muted-foreground hover:border-gold/40 hover:text-foreground'
              )}
            >
              {CATEGORY_LABELS[cat]}
            </button>
          ))}
        </motion.div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 gap-x-16 gap-y-6">
          {filtered.map((skill, i) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, x: -20 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 + i * 0.04 }}
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-foreground">{skill.name}</span>
                <span className="text-xs font-mono text-gold">{skill.level}%</span>
              </div>
              <div className="skill-bar">
                <motion.div
                  className="skill-bar-fill"
                  initial={{ width: 0 }}
                  animate={inView ? { width: `${skill.level}%` } : { width: 0 }}
                  transition={{ duration: 1.2, delay: 0.3 + i * 0.04, ease: [0.16, 1, 0.3, 1] }}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Stats row */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20"
        >
          {[
            { number: '6+', label: 'Projects Shipped' },
            { number: '3', label: 'Years Coding' },
            { number: '2', label: 'SkillsUSA Medals' },
            { number: '20+', label: 'Technologies' },
          ].map(({ number, label }) => (
            <div
              key={label}
              className="text-center p-6 rounded-2xl border border-border bg-card/50 hover:border-gold/30 transition-colors"
            >
              <div className="text-3xl font-display gradient-text mb-1">{number}</div>
              <div className="text-xs text-muted-foreground uppercase tracking-widest">{label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
