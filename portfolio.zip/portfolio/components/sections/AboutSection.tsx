// ============================================================
// components/sections/AboutSection.tsx
// ============================================================
'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { MapPin, Mail, Github, Linkedin, ExternalLink } from 'lucide-react';
import { PERSONAL_INFO, TECH_STACK_LOGOS } from '@/data/portfolio';
import { Button } from '@/components/ui/button';

export default function AboutSection() {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.15 });

  return (
    <section id="about" className="py-32 relative" ref={ref}>
      <div className="max-w-6xl mx-auto px-6">
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-3 mb-16"
        >
          <div className="w-8 h-px bg-gold" />
          <span className="text-gold text-sm font-mono tracking-widest uppercase">01 — About</span>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left: Avatar + info */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            {/* Avatar placeholder */}
            <div className="relative w-56 h-56 mb-8">
              <div className="w-full h-full rounded-3xl bg-gradient-to-br from-gold/20 to-navy-light/40 border border-gold/20 flex items-center justify-center text-6xl font-display text-gold">
                AR
              </div>
              {/* Decorative corner */}
              <div className="absolute -bottom-3 -right-3 w-full h-full rounded-3xl border border-gold/15 -z-10" />
            </div>

            {/* Contact info */}
            <div className="space-y-3 mb-8">
              {[
                { Icon: MapPin, text: PERSONAL_INFO.location },
                { Icon: Mail, text: PERSONAL_INFO.email, href: `mailto:${PERSONAL_INFO.email}` },
                { Icon: Github, text: 'github.com/alexrivera', href: PERSONAL_INFO.github },
                { Icon: Linkedin, text: 'linkedin.com/in/alexrivera', href: PERSONAL_INFO.linkedin },
              ].map(({ Icon, text, href }) => (
                <div key={text} className="flex items-center gap-3 text-sm text-muted-foreground">
                  <Icon size={15} className="text-gold flex-shrink-0" />
                  {href ? (
                    <a href={href} target="_blank" rel="noopener noreferrer"
                      className="hover:text-gold transition-colors hover:underline underline-offset-2">
                      {text}
                    </a>
                  ) : (
                    <span>{text}</span>
                  )}
                </div>
              ))}
            </div>

            <a href={PERSONAL_INFO.resumeUrl} target="_blank" rel="noopener noreferrer">
              <Button variant="outline-gold" className="gap-2">
                <ExternalLink size={15} />
                View Full Resume
              </Button>
            </a>
          </motion.div>

          {/* Right: Bio */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          >
            <h2 className="section-heading text-foreground mb-6" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
              Building at the intersection of{' '}
              <em className="gradient-text not-italic">craft & code</em>
            </h2>

            <p className="text-muted-foreground leading-relaxed mb-4">
              {PERSONAL_INFO.bio}
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              {PERSONAL_INFO.bioExtended}
            </p>

            {/* SkillsUSA highlight */}
            <div className="p-5 rounded-2xl border border-gold/20 bg-gold/5">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-gold/15 flex items-center justify-center flex-shrink-0">
                  <span className="text-gold text-lg">🏆</span>
                </div>
                <div>
                  <p className="font-medium text-foreground text-sm mb-1">
                    {PERSONAL_INFO.skillsusa.competition}
                  </p>
                  <p className="text-xs text-muted-foreground mb-2">
                    {PERSONAL_INFO.skillsusa.chapter} • {PERSONAL_INFO.skillsusa.year}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {PERSONAL_INFO.skillsusa.achievements.map((a) => (
                      <span key={a} className="text-xs px-2 py-0.5 rounded-full bg-gold/10 text-gold-light border border-gold/20">
                        {a}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Tech stack marquee */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-20 overflow-hidden"
        >
          <p className="text-center text-xs text-muted-foreground uppercase tracking-widest font-mono mb-6">
            Technologies I work with
          </p>
          <div className="relative">
            <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-background to-transparent z-10" />
            <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-background to-transparent z-10" />
            <div className="flex gap-6 animate-marquee whitespace-nowrap">
              {[...TECH_STACK_LOGOS, ...TECH_STACK_LOGOS].map((tech, i) => (
                <span
                  key={`${tech}-${i}`}
                  className="inline-flex items-center px-4 py-2 rounded-full border border-border text-sm text-muted-foreground font-mono hover:border-gold/30 hover:text-foreground transition-colors cursor-default"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
