// ============================================================
// types/index.ts — Shared TypeScript types for the portfolio
// ============================================================

export interface Project {
  _id?: string;
  id?: string;
  title: string;
  description: string;
  longDescription?: string;
  techStack: string[];
  imageUrl?: string;
  images?: string[];
  githubUrl?: string;
  liveUrl?: string;
  featured: boolean;
  category: 'web' | 'mobile' | 'ai' | 'backend' | 'other';
  year: number;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Skill {
  name: string;
  level: number; // 0–100
  icon?: string;
  category: 'frontend' | 'backend' | 'devops' | 'design' | 'language' | 'tool';
}

export interface TimelineItem {
  year: string;
  title: string;
  subtitle: string;
  description: string;
  type: 'education' | 'work' | 'achievement';
  icon?: string;
}

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  readTime: string;
  tags: string[];
  imageUrl?: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface SocialLink {
  platform: string;
  url: string;
  icon: string;
}

export interface GitHubRepo {
  name: string;
  description: string;
  html_url: string;
  stargazers_count: number;
  language: string;
  topics: string[];
  updated_at: string;
}
