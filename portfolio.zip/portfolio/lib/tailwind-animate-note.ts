// ============================================================
// NOTE: tailwindcss-animate is provided by the tailwindcss-animate npm package.
// This file is a placeholder reminder — the real plugin is installed via npm.
// Run: npm install tailwindcss-animate
// It is already listed in package.json dependencies below.
// ============================================================

// No code needed here — imported directly in tailwind.config.ts as:
//   plugins: [require('tailwindcss-animate')]
