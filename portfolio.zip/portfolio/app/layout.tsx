// ============================================================
// app/layout.tsx — Root layout with ThemeProvider and metadata
// ============================================================
import type { Metadata } from 'next';
import { ThemeProvider } from '@/components/ui/theme-provider';
import Navbar from '@/components/sections/Navbar';
import Footer from '@/components/sections/Footer';
import '@/styles/globals.css';

export const metadata: Metadata = {
  title: {
    default: 'Alex Rivera — Full-Stack Developer & Designer',
    template: '%s | Alex Rivera',
  },
  description:
    'Full-stack developer and UI/UX designer. SkillsUSA 2025 competitor specializing in React, Node.js, and modern web technologies.',
  keywords: [
    'full-stack developer',
    'React',
    'Next.js',
    'TypeScript',
    'SkillsUSA',
    'portfolio',
    'web developer',
    'UI/UX designer',
  ],
  authors: [{ name: 'Alex Rivera' }],
  creator: 'Alex Rivera',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://alexrivera.dev',
    siteName: 'Alex Rivera Portfolio',
    title: 'Alex Rivera — Full-Stack Developer & Designer',
    description:
      'Full-stack developer and UI/UX designer. SkillsUSA 2025 competitor specializing in React, Node.js, and modern web technologies.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Alex Rivera Portfolio',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Alex Rivera — Full-Stack Developer & Designer',
    description: 'Full-stack developer and UI/UX designer. SkillsUSA 2025 competitor.',
    images: ['/og-image.jpg'],
    creator: '@alexrivera',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      </head>
      <body className="noise-bg min-h-screen">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange={false}
        >
          <Navbar />
          <main>{children}</main>
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  );
}
