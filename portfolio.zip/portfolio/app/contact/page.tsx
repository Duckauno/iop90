// ============================================================
// app/contact/page.tsx — Standalone contact page
// ============================================================
import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import ContactSection from '@/components/sections/ContactSection';

export const metadata: Metadata = {
  title: 'Contact',
  description: 'Get in touch with Alex Rivera — for collaboration, opportunities, or just to say hi.',
};

export default function ContactPage() {
  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-6xl mx-auto px-6 pt-8">
        <Link
          href="/#contact"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-gold transition-colors mb-4"
        >
          <ArrowLeft size={14} /> Back to home
        </Link>
      </div>
      <ContactSection />
    </div>
  );
}
