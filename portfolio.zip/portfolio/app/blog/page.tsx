// ============================================================
// app/blog/page.tsx — Blog listing page
// ============================================================
import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { Clock, Tag, ArrowLeft } from 'lucide-react';
import { BLOG_POSTS } from '@/data/portfolio';
import { formatDate } from '@/lib/utils';

export const metadata: Metadata = {
  title: 'Blog',
  description: 'Articles about web development, design, and SkillsUSA.',
};

export default function BlogPage() {
  return (
    <div className="min-h-screen pt-28 pb-20">
      <div className="max-w-4xl mx-auto px-6">
        <Link
          href="/#blog"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-gold transition-colors mb-8"
        >
          <ArrowLeft size={14} /> Back to home
        </Link>

        <h1 className="section-heading text-foreground mb-4" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
          Writing
        </h1>
        <p className="text-muted-foreground mb-12">
          Thoughts on development, design, and the lessons learned along the way.
        </p>

        <div className="space-y-8">
          {BLOG_POSTS.map((post) => (
            <article
              key={post.slug}
              className="group flex flex-col md:flex-row gap-6 p-6 rounded-2xl border border-border hover:border-gold/30 bg-card/40 hover:bg-card/60 transition-all"
            >
              {post.imageUrl && (
                <div className="relative w-full md:w-48 h-36 rounded-xl overflow-hidden flex-shrink-0">
                  <Image
                    src={post.imageUrl}
                    alt={post.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(max-width: 768px) 100vw, 192px"
                  />
                </div>
              )}

              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2 text-xs text-muted-foreground">
                  <span>{formatDate(post.date)}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1"><Clock size={11} /> {post.readTime}</span>
                </div>

                <h2 className="font-display text-xl font-medium text-foreground mb-2 group-hover:text-gold transition-colors">
                  {post.title}
                </h2>

                <p className="text-sm text-muted-foreground leading-relaxed mb-4">{post.excerpt}</p>

                <div className="flex flex-wrap gap-1.5">
                  {post.tags.map((tag) => (
                    <span
                      key={tag}
                      className="flex items-center gap-1 font-mono text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground"
                    >
                      <Tag size={8} /> {tag}
                    </span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
