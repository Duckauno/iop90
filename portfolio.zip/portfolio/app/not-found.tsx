// ============================================================
// app/not-found.tsx — 404 page
// ============================================================
'use client';

import React from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowLeft, Code2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center max-w-lg"
      >
        {/* Big 404 */}
        <div className="relative mb-8">
          <span
            className="font-display font-bold select-none"
            style={{
              fontSize: 'clamp(6rem, 20vw, 12rem)',
              color: 'transparent',
              WebkitTextStroke: '1px rgba(201,168,76,0.2)',
              lineHeight: 1,
            }}
          >
            404
          </span>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-2xl bg-gold/15 border border-gold/30 flex items-center justify-center">
              <Code2 size={28} className="text-gold" />
            </div>
          </div>
        </div>

        <h1 className="font-display text-3xl font-medium text-foreground mb-3">
          Page not found
        </h1>
        <p className="text-muted-foreground mb-8">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>

        <Link href="/">
          <Button variant="gold" size="lg">
            <ArrowLeft size={16} />
            Back to Portfolio
          </Button>
        </Link>
      </motion.div>
    </div>
  );
}
