// ============================================================
// app/projects/page.tsx — Full projects listing page
// ============================================================
import React from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import ProjectsSection from '@/components/sections/ProjectsSection';

export const metadata: Metadata = {
  title: 'Projects',
  description: 'Full-stack projects built by Alex Rivera — web apps, mobile, AI, and more.',
};

export default function ProjectsPage() {
  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-6 pt-8">
        <Link
          href="/#projects"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-gold transition-colors mb-4"
        >
          <ArrowLeft size={14} /> Back to home
        </Link>
      </div>
      <ProjectsSection />
    </div>
  );
}
