// ============================================================
// app/page.tsx — Home page, assembles all sections
// ============================================================
import HeroSection from '@/components/sections/HeroSection';
import AboutSection from '@/components/sections/AboutSection';
import SkillsSection from '@/components/sections/SkillsSection';
import ProjectsSection from '@/components/sections/ProjectsSection';
import SkillsUSASection from '@/components/sections/SkillsUSASection';
import BlogSection from '@/components/sections/BlogSection';
import ContactSection from '@/components/sections/ContactSection';
import TimelineSection from '@/components/sections/TimelineSection';

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <TimelineSection />
      <ProjectsSection />
      <SkillsUSASection />
      <BlogSection />
      <ContactSection />
    </>
  );
}
