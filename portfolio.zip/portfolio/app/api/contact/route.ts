// ============================================================
// app/api/contact/route.ts — Contact form API handler
// ============================================================
import { NextRequest, NextResponse } from 'next/server';
import nodemailer from 'nodemailer';
import { z } from 'zod';

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  subject: z.string().min(5),
  message: z.string().min(20),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { success: false, message: 'Invalid form data', errors: parsed.error.errors },
        { status: 400 }
      );
    }

    const { name, email, subject, message } = parsed.data;

    // Create transporter
    // For Gmail: enable "Less secure apps" or use App Password
    // For production: use SendGrid, Resend, or Mailgun
    const transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.EMAIL_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    // If email credentials aren't configured, just log and return success
    // (useful for development/demo)
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
      console.log('📧 [Contact Form Submission - No Email Configured]');
      console.log({ name, email, subject, message });
      return NextResponse.json(
        { success: true, message: 'Message received (email not configured)' },
        { status: 200 }
      );
    }

    // Email to portfolio owner
    await transporter.sendMail({
      from: `"Portfolio Contact" <${process.env.EMAIL_USER}>`,
      to: process.env.EMAIL_TO || process.env.EMAIL_USER,
      subject: `[Portfolio] ${subject} — from ${name}`,
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0A1628; color: #E8E8E8; padding: 40px; border-radius: 16px;">
          <div style="border-bottom: 1px solid rgba(201,168,76,0.3); padding-bottom: 20px; margin-bottom: 24px;">
            <h1 style="color: #C9A84C; font-size: 24px; margin: 0;">New Portfolio Message</h1>
          </div>
          <table style="width: 100%; border-collapse: collapse;">
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px; width: 80px;">From</td><td style="padding: 8px 0; font-weight: 600;">${name}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Email</td><td style="padding: 8px 0;"><a href="mailto:${email}" style="color: #C9A84C;">${email}</a></td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Subject</td><td style="padding: 8px 0;">${subject}</td></tr>
          </table>
          <div style="margin-top: 24px; padding: 20px; background: rgba(255,255,255,0.05); border-radius: 12px; border-left: 3px solid #C9A84C;">
            <p style="margin: 0; line-height: 1.7; white-space: pre-wrap;">${message}</p>
          </div>
          <p style="margin-top: 24px; color: #555; font-size: 12px;">Sent from your portfolio contact form at ${new Date().toLocaleString()}</p>
        </div>
      `,
    });

    // Auto-reply to sender
    await transporter.sendMail({
      from: `"Alex Rivera" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `Thanks for reaching out, ${name.split(' ')[0]}!`,
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0A1628; color: #E8E8E8; padding: 40px; border-radius: 16px;">
          <h2 style="color: #C9A84C; font-size: 22px; margin-bottom: 16px;">Thanks for your message!</h2>
          <p style="line-height: 1.7; color: #ccc;">Hi ${name.split(' ')[0]},</p>
          <p style="line-height: 1.7; color: #ccc;">I received your message and will get back to you within 24 hours. I'm excited to connect!</p>
          <p style="line-height: 1.7; color: #ccc;">In the meantime, feel free to check out my latest projects on <a href="https://github.com/alexrivera" style="color: #C9A84C;">GitHub</a>.</p>
          <p style="line-height: 1.7; color: #ccc;">Best,<br/><strong style="color: #E8E8E8;">Alex Rivera</strong><br/><span style="color: #888; font-size: 13px;">Full-Stack Developer · SkillsUSA 2025</span></p>
        </div>
      `,
    });

    return NextResponse.json({ success: true, message: 'Message sent successfully!' });
  } catch (error) {
    console.error('Contact form error:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to send message. Please try again.' },
      { status: 500 }
    );
  }
}
