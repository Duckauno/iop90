// ============================================================
// app/api/projects/route.ts — Projects CRUD API
// ============================================================
import { NextRequest, NextResponse } from 'next/server';
import { PROJECTS } from '@/data/portfolio';

// In-memory store for demo (replace with MongoDB in production)
let projectsStore = [...PROJECTS];

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get('category');
    const featured = searchParams.get('featured');
    const search = searchParams.get('search');

    let results = [...projectsStore];

    if (category && category !== 'all') {
      results = results.filter((p) => p.category === category);
    }

    if (featured === 'true') {
      results = results.filter((p) => p.featured);
    }

    if (search) {
      const q = search.toLowerCase();
      results = results.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.techStack.some((t) => t.toLowerCase().includes(q))
      );
    }

    return NextResponse.json({ success: true, data: results, count: results.length });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Failed to fetch projects' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    // Verify admin token
    const authHeader = req.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const newProject = {
      ...body,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    projectsStore.unshift(newProject);

    return NextResponse.json({ success: true, data: newProject }, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Failed to create project' },
      { status: 500 }
    );
  }
}
