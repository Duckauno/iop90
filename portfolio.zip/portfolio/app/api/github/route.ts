// ============================================================
// app/api/github/route.ts — GitHub API integration
// ============================================================
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const username = process.env.GITHUB_USERNAME || 'alexrivera';
  const token = process.env.GITHUB_TOKEN;

  try {
    const headers: Record<string, string> = {
      Accept: 'application/vnd.github.v3+json',
    };

    if (token) {
      headers['Authorization'] = `token ${token}`;
    }

    const [reposRes, userRes] = await Promise.all([
      fetch(
        `https://api.github.com/users/${username}/repos?sort=updated&per_page=6&type=public`,
        { headers, next: { revalidate: 3600 } } // cache 1 hour
      ),
      fetch(`https://api.github.com/users/${username}`, {
        headers,
        next: { revalidate: 3600 },
      }),
    ]);

    if (!reposRes.ok || !userRes.ok) {
      throw new Error('GitHub API error');
    }

    const [repos, user] = await Promise.all([reposRes.json(), userRes.json()]);

    return NextResponse.json({
      success: true,
      data: {
        repos,
        user: {
          name: user.name,
          bio: user.bio,
          public_repos: user.public_repos,
          followers: user.followers,
          avatar_url: user.avatar_url,
          html_url: user.html_url,
        },
      },
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Failed to fetch GitHub data' },
      { status: 500 }
    );
  }
}
