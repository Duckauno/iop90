// ============================================================
// app/admin/page.tsx — Admin dashboard
// ============================================================
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LogIn, LogOut, Plus, Trash2, Edit3, Eye, EyeOff,
  LayoutDashboard, FolderOpen, Users, Mail, Code2, CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { PROJECTS } from '@/data/portfolio';
import type { Project } from '@/types';

// ─── Login Form ────────────────────────────────────────────
function LoginForm({ onLogin }: { onLogin: (token: string) => void }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (data.success) {
        onLogin(data.token);
      } else {
        setError(data.message || 'Invalid credentials');
      }
    } catch {
      setError('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gold/20 border border-gold/30 flex items-center justify-center">
            <Code2 size={18} className="text-gold" />
          </div>
          <div>
            <h1 className="font-display text-xl font-medium text-foreground">Admin Dashboard</h1>
            <p className="text-xs text-muted-foreground">Portfolio Management</p>
          </div>
        </div>

        <div className="p-8 rounded-3xl border border-border bg-card">
          <h2 className="font-display text-2xl font-medium text-foreground mb-2">Sign In</h2>
          <p className="text-sm text-muted-foreground mb-6">
            Default: admin / admin123 (change in .env)
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-sm text-destructive bg-destructive/10 px-3 py-2 rounded-lg">{error}</p>
            )}

            <Button type="submit" variant="gold" className="w-full" disabled={loading}>
              {loading ? (
                <span className="inline-block w-4 h-4 border-2 border-navy/40 border-t-navy rounded-full animate-spin" />
              ) : (
                <LogIn size={15} />
              )}
              {loading ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}

// ─── Add/Edit Project Form ──────────────────────────────────
function ProjectForm({
  project,
  onSave,
  onCancel,
  token,
}: {
  project?: Project;
  onSave: (p: Project) => void;
  onCancel: () => void;
  token: string;
}) {
  const [form, setForm] = useState<Partial<Project>>(
    project || {
      title: '',
      description: '',
      longDescription: '',
      techStack: [],
      imageUrl: '',
      githubUrl: '',
      liveUrl: '',
      featured: false,
      category: 'web',
      year: new Date().getFullYear(),
    }
  );
  const [techInput, setTechInput] = useState(project?.techStack.join(', ') || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const payload = { ...form, techStack: techInput.split(',').map((t) => t.trim()).filter(Boolean) };

    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success) {
        setSaved(true);
        setTimeout(() => { onSave(data.data); setSaved(false); }, 800);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-6 rounded-2xl border border-gold/20 bg-card"
    >
      <h3 className="font-display text-xl font-medium text-foreground mb-6">
        {project ? 'Edit Project' : 'Add New Project'}
      </h3>

      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <div className="space-y-2">
          <Label>Title *</Label>
          <Input value={form.title || ''} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Project title" />
        </div>
        <div className="space-y-2">
          <Label>Category</Label>
          <select
            value={form.category || 'web'}
            onChange={(e) => setForm({ ...form, category: e.target.value as Project['category'] })}
            className="flex h-11 w-full rounded-xl border border-input bg-background/50 px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-gold focus:border-gold transition-all"
          >
            {['web', 'mobile', 'ai', 'backend', 'other'].map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <Label>Year</Label>
          <Input
            type="number"
            value={form.year || 2024}
            onChange={(e) => setForm({ ...form, year: parseInt(e.target.value) })}
          />
        </div>
        <div className="space-y-2">
          <Label>Image URL</Label>
          <Input value={form.imageUrl || ''} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} placeholder="https://..." />
        </div>
        <div className="space-y-2">
          <Label>GitHub URL</Label>
          <Input value={form.githubUrl || ''} onChange={(e) => setForm({ ...form, githubUrl: e.target.value })} placeholder="https://github.com/..." />
        </div>
        <div className="space-y-2">
          <Label>Live URL</Label>
          <Input value={form.liveUrl || ''} onChange={(e) => setForm({ ...form, liveUrl: e.target.value })} placeholder="https://..." />
        </div>
      </div>

      <div className="space-y-4 mb-4">
        <div className="space-y-2">
          <Label>Short Description *</Label>
          <Textarea rows={2} value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Brief description..." />
        </div>
        <div className="space-y-2">
          <Label>Long Description</Label>
          <Textarea rows={4} value={form.longDescription || ''} onChange={(e) => setForm({ ...form, longDescription: e.target.value })} placeholder="Detailed description..." />
        </div>
        <div className="space-y-2">
          <Label>Tech Stack (comma separated)</Label>
          <Input value={techInput} onChange={(e) => setTechInput(e.target.value)} placeholder="React, TypeScript, Node.js..." />
        </div>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="featured"
            checked={form.featured || false}
            onChange={(e) => setForm({ ...form, featured: e.target.checked })}
            className="rounded accent-gold"
          />
          <Label htmlFor="featured">Featured project</Label>
        </div>
      </div>

      <div className="flex gap-3">
        <Button variant="gold" onClick={handleSave} disabled={saving || saved}>
          {saved ? <CheckCircle size={15} /> : saving ? (
            <span className="inline-block w-4 h-4 border-2 border-navy/40 border-t-navy rounded-full animate-spin" />
          ) : <Plus size={15} />}
          {saved ? 'Saved!' : saving ? 'Saving...' : 'Save Project'}
        </Button>
        <Button variant="outline-gold" onClick={onCancel}>Cancel</Button>
      </div>
    </motion.div>
  );
}

// ─── Main Dashboard ─────────────────────────────────────────
export default function AdminPage() {
  const [token, setToken] = useState<string | null>(null);
  const [projects, setProjects] = useState<Project[]>(PROJECTS);
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'projects' | 'messages'>('overview');

  const stats = [
    { label: 'Total Projects', value: projects.length, Icon: FolderOpen, color: 'text-blue-400' },
    { label: 'Featured', value: projects.filter((p) => p.featured).length, Icon: Eye, color: 'text-gold' },
    { label: 'Categories', value: new Set(projects.map((p) => p.category)).size, Icon: LayoutDashboard, color: 'text-purple-400' },
    { label: 'Total Visitors', value: '1.2k', Icon: Users, color: 'text-green-400' },
  ];

  if (!token) {
    return <LoginForm onLogin={setToken} />;
  }

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-3xl font-medium text-foreground">Dashboard</h1>
            <p className="text-muted-foreground text-sm">Manage your portfolio content</p>
          </div>
          <Button
            variant="outline-gold"
            onClick={async () => {
              await fetch('/api/admin', { method: 'DELETE' });
              setToken(null);
            }}
          >
            <LogOut size={15} /> Sign Out
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {stats.map(({ label, value, Icon, color }) => (
            <div key={label} className="p-5 rounded-2xl border border-border bg-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-muted-foreground uppercase tracking-widest">{label}</span>
                <Icon size={16} className={color} />
              </div>
              <p className="text-2xl font-display font-medium text-foreground">{value}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl bg-muted w-fit mb-8">
          {(['overview', 'projects', 'messages'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all capitalize ${
                activeTab === tab
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Projects Tab */}
        {activeTab === 'projects' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-xl text-foreground">Projects</h2>
              <Button variant="gold" onClick={() => setShowForm(true)}>
                <Plus size={15} /> Add Project
              </Button>
            </div>

            {showForm && (
              <div className="mb-6">
                <ProjectForm
                  token={token}
                  onSave={(p) => { setProjects((prev) => [p, ...prev]); setShowForm(false); }}
                  onCancel={() => setShowForm(false)}
                />
              </div>
            )}

            <div className="space-y-3">
              {projects.map((project) => (
                <div
                  key={project.id}
                  className="flex items-center gap-4 p-4 rounded-xl border border-border bg-card hover:border-gold/20 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium text-foreground text-sm truncate">{project.title}</h3>
                      {project.featured && <Badge variant="gold" className="text-[10px]">Featured</Badge>}
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="tech">{project.category}</Badge>
                      <span className="text-xs text-muted-foreground">{project.year}</span>
                      <span className="text-xs text-muted-foreground">
                        {project.techStack.slice(0, 3).join(' · ')}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" className="text-muted-foreground">
                      <Edit3 size={14} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-muted-foreground hover:text-destructive"
                      onClick={() => setProjects((prev) => prev.filter((p) => p.id !== project.id))}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl border border-border bg-card">
              <h3 className="font-display text-lg text-foreground mb-4 flex items-center gap-2">
                <FolderOpen size={18} className="text-gold" /> Recent Projects
              </h3>
              <div className="space-y-3">
                {projects.slice(0, 4).map((p) => (
                  <div key={p.id} className="flex items-center justify-between">
                    <span className="text-sm text-foreground truncate">{p.title}</span>
                    <Badge variant="tech">{p.category}</Badge>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-6 rounded-2xl border border-border bg-card">
              <h3 className="font-display text-lg text-foreground mb-4 flex items-center gap-2">
                <Mail size={18} className="text-gold" /> Quick Actions
              </h3>
              <div className="space-y-3">
                <Button variant="outline-gold" className="w-full justify-start" onClick={() => setActiveTab('projects')}>
                  <Plus size={15} /> Add New Project
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/" target="_blank">
                    <Eye size={15} /> Preview Portfolio
                  </a>
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Messages Tab */}
        {activeTab === 'messages' && (
          <div className="p-8 rounded-2xl border border-border bg-card text-center">
            <Mail size={32} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="font-display text-xl text-foreground mb-2">Messages</h3>
            <p className="text-muted-foreground text-sm">
              Connect a database (MongoDB) to store and view contact form submissions here.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
