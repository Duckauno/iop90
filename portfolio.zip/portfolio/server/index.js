// ============================================================
// server/index.js — Express backend server (port 3001)
// Handles email via Nodemailer and serves as API fallback
// ============================================================
require('dotenv').config({ path: '.env.local' });

const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.EXPRESS_PORT || 3001;

// ── Middleware ────────────────────────────────────────────
app.use(express.json());
app.use(cors({
  origin: process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
  credentials: true,
}));

// ── Health check ─────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'Portfolio Express Server',
  });
});

// ── Contact form (backup handler) ────────────────────────
app.post('/api/contact', async (req, res) => {
  const { name, email, subject, message } = req.body;

  if (!name || !email || !subject || !message) {
    return res.status(400).json({ success: false, message: 'All fields are required.' });
  }

  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ success: false, message: 'Invalid email address.' });
  }

  // Log submission
  console.log('\n📬 New contact form submission:');
  console.log(`  From:    ${name} <${email}>`);
  console.log(`  Subject: ${subject}`);
  console.log(`  Message: ${message.substring(0, 100)}${message.length > 100 ? '...' : ''}`);
  console.log('');

  // Send email if configured
  if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.EMAIL_HOST || 'smtp.gmail.com',
        port: parseInt(process.env.EMAIL_PORT || '587'),
        secure: false,
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASS,
        },
      });

      await transporter.sendMail({
        from: `"Portfolio Contact" <${process.env.EMAIL_USER}>`,
        to: process.env.EMAIL_TO || process.env.EMAIL_USER,
        subject: `[Portfolio] ${subject} — from ${name}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; background: #0A1628; color: #E8E8E8; padding: 32px; border-radius: 12px;">
            <h2 style="color: #C9A84C;">New Message from ${name}</h2>
            <p><strong>Email:</strong> <a href="mailto:${email}" style="color: #C9A84C;">${email}</a></p>
            <p><strong>Subject:</strong> ${subject}</p>
            <hr style="border-color: rgba(201,168,76,0.2); margin: 16px 0;">
            <p style="white-space: pre-wrap; line-height: 1.7;">${message}</p>
            <hr style="border-color: rgba(201,168,76,0.2); margin: 16px 0;">
            <p style="color: #666; font-size: 12px;">Sent at ${new Date().toLocaleString()}</p>
          </div>
        `,
      });

      console.log('✅ Email sent successfully');
    } catch (emailError) {
      console.error('❌ Email error:', emailError.message);
      // Still return success — the message was received even if email failed
    }
  } else {
    console.log('ℹ️  Email not configured — submission logged above');
  }

  return res.json({ success: true, message: 'Message received! I\'ll be in touch soon.' });
});

// ── GitHub stats proxy (avoids CORS and rate limits) ─────
app.get('/api/github/:username', async (req, res) => {
  const { username } = req.params;
  try {
    const headers = {};
    if (process.env.GITHUB_TOKEN) {
      headers['Authorization'] = `token ${process.env.GITHUB_TOKEN}`;
    }

    const response = await fetch(`https://api.github.com/users/${username}/repos?sort=updated&per_page=6`, {
      headers,
    });

    if (!response.ok) {
      throw new Error(`GitHub API error: ${response.status}`);
    }

    const repos = await response.json();
    return res.json({ success: true, data: repos });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// ── 404 handler ───────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.path} not found` });
});

// ── Error handler ─────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

// ── Start server ──────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 Portfolio Express server running on http://localhost:${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/health`);
  console.log(`   Email configured: ${!!(process.env.EMAIL_USER && process.env.EMAIL_PASS)}`);
  console.log('');
});

module.exports = app;
